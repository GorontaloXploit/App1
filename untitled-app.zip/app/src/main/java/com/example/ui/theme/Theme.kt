package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val TradingDarkColorScheme = darkColorScheme(
  primary = AccentPrimary,
  onPrimary = TextPrimary,
  primaryContainer = SurfaceElevated,
  onPrimaryContainer = TextPrimary,
  secondary = LiquidityCyan,
  onSecondary = BgObsidian,
  secondaryContainer = SurfaceCard,
  onSecondaryContainer = TextPrimary,
  tertiary = BullGreen,
  onTertiary = BgObsidian,
  background = BgObsidian,
  onBackground = TextPrimary,
  surface = SurfaceDark,
  onSurface = TextPrimary,
  surfaceVariant = SurfaceCard,
  onSurfaceVariant = TextSecondary,
  outline = SurfaceBorder,
  outlineVariant = SurfaceElevated,
  error = BearRed,
  onError = TextPrimary
)

private val TradingLightColorScheme = lightColorScheme(
  primary = AccentPrimary,
  onPrimary = TextPrimary,
  background = BgObsidian,
  surface = SurfaceDark,
  onSurface = TextPrimary
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Preserve our bespoke trading dark terminal palette
  content: @Composable () -> Unit,
) {
  val colorScheme = TradingDarkColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

