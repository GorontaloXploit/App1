package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TimeFrame
import com.example.ui.components.*
import com.example.ui.theme.BgObsidian

@Composable
fun MainTradingScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val selectedPair by viewModel.selectedPair.collectAsStateWithLifecycle()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsStateWithLifecycle()
    val viewMode by viewModel.viewMode.collectAsStateWithLifecycle()
    val candles by viewModel.candles.collectAsStateWithLifecycle()
    val zones by viewModel.zones.collectAsStateWithLifecycle()
    val liquidityLevels by viewModel.liquidityLevels.collectAsStateWithLifecycle()
    val analysesMap by viewModel.analysesMap.collectAsStateWithLifecycle()
    val confluence by viewModel.confluence.collectAsStateWithLifecycle()
    val savedSetups by viewModel.savedSetups.collectAsStateWithLifecycle()

    var showLiquidityOnChart by remember { mutableStateOf(true) }
    var showZonesOnChart by remember { mutableStateOf(true) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column {
                TopTradingBar(
                    pair = selectedPair,
                    availablePairs = viewModel.availablePairs,
                    confluence = confluence,
                    onSelectPair = { viewModel.selectPair(it) },
                    onAutoScanAll = { viewModel.autoScanAllTimeframes() }
                )
                TimeframeTabBar(
                    selectedTimeframe = selectedTimeframe,
                    currentViewMode = viewMode,
                    onSelectTimeframe = { viewModel.selectTimeframe(it) },
                    onSelectViewMode = { viewModel.setViewMode(it) }
                )
            }
        },
        containerColor = BgObsidian
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (viewMode) {
                ViewMode.CHART -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Candlestick Chart
                        CandlestickChart(
                            candles = candles,
                            zones = zones,
                            liquidityLevels = liquidityLevels,
                            pair = selectedPair,
                            timeframe = selectedTimeframe,
                            showLiquidityOverlay = showLiquidityOnChart,
                            showZonesOverlay = showZonesOnChart
                        )

                        // Timeframe Analysis & Role Card
                        val currentAnalysis = analysesMap[selectedTimeframe]
                        TimeframeAnalysisCard(
                            timeframe = selectedTimeframe,
                            analysis = currentAnalysis,
                            pair = selectedPair,
                            onUpdateAnalysis = { viewModel.updateAnalysis(it) },
                            onAutoScan = { viewModel.autoScanAndSaveCurrentTimeframe() },
                            onOpenConfluence = { viewModel.setViewMode(ViewMode.CONFLUENCE) }
                        )

                        // Quick Synthesis Bar at bottom
                        QuickConfluenceBar(
                            confluence = confluence,
                            onOpenConfluence = { viewModel.setViewMode(ViewMode.CONFLUENCE) },
                            onOpenHeatmap = { viewModel.setViewMode(ViewMode.HEATMAP) }
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                ViewMode.HEATMAP -> {
                    LiquidityHeatmapScreen(
                        pair = selectedPair,
                        liquidityLevels = liquidityLevels
                    )
                }

                ViewMode.CONFLUENCE -> {
                    MultiTfConfluenceScreen(
                        pair = selectedPair,
                        confluence = confluence,
                        analysesMap = analysesMap,
                        onSaveToJournal = { notes ->
                            viewModel.saveCurrentConfluenceToJournal(notes)
                        },
                        onNavigateToTimeframe = { tf ->
                            viewModel.selectTimeframe(tf)
                            viewModel.setViewMode(ViewMode.CHART)
                        }
                    )
                }

                ViewMode.JOURNAL -> {
                    TradingJournalScreen(
                        savedSetups = savedSetups,
                        onDeleteSetup = { viewModel.deleteJournalEntry(it) }
                    )
                }
            }
        }
    }
}
