package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TimeFrame
import com.example.ui.ViewMode
import com.example.ui.theme.*

@Composable
fun TimeframeTabBar(
    selectedTimeframe: TimeFrame,
    currentViewMode: ViewMode,
    onSelectTimeframe: (TimeFrame) -> Unit,
    onSelectViewMode: (ViewMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("timeframe_tab_bar")
    ) {
        // 1. Navigation View Modes (Grafik, Heatmap, Confluence, Jurnal)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModeButton(
                title = "Grafik Multi-TF",
                icon = Icons.Default.CandlestickChart,
                isSelected = currentViewMode == ViewMode.CHART,
                onClick = { onSelectViewMode(ViewMode.CHART) }
            )
            ModeButton(
                title = "Liquidity Heatmap",
                icon = Icons.Default.Layers,
                badge = "Heatmap",
                isSelected = currentViewMode == ViewMode.HEATMAP,
                onClick = { onSelectViewMode(ViewMode.HEATMAP) }
            )
            ModeButton(
                title = "Penyatuan Sinyal",
                icon = Icons.Default.FactCheck,
                badge = "Confluence",
                isSelected = currentViewMode == ViewMode.CONFLUENCE,
                onClick = { onSelectViewMode(ViewMode.CONFLUENCE) }
            )
            ModeButton(
                title = "Jurnal",
                icon = Icons.Default.MenuBook,
                isSelected = currentViewMode == ViewMode.JOURNAL,
                onClick = { onSelectViewMode(ViewMode.JOURNAL) }
            )
        }

        // 2. Timeframe Selector (Only shown if in CHART mode)
        if (currentViewMode == ViewMode.CHART) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TimeFrame.values().forEach { tf ->
                    val isSelected = selectedTimeframe == tf
                    val roleSummary = when (tf) {
                        TimeFrame.D1 -> "Bias 9B"
                        TimeFrame.H4 -> "Target 3B"
                        TimeFrame.H1 -> "Struktur 4M"
                        TimeFrame.M15 -> "Entry M15"
                    }

                    Surface(
                        color = if (isSelected) AccentPrimary else SurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { onSelectTimeframe(tf) }
                            .testTag("tf_tab_${tf.code}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = tf.code,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = roleSummary,
                                color = if (isSelected) Color.White.copy(alpha = 0.85f) else TextMuted,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeButton(
    title: String,
    icon: ImageVector,
    badge: String? = null,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) AccentPrimaryDim else SurfaceElevated,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) AccentPrimary else SurfaceBorder
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) AccentPrimary else TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) TextPrimary else TextSecondary,
                fontSize = 11.5.sp
            )
            if (badge != null && !isSelected) {
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    color = LiquidityCyan.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = badge,
                        color = LiquidityCyan,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}
