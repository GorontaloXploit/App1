package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Trading Terminal Dark Theme Palette
val BgObsidian = Color(0xFF090D14)
val SurfaceDark = Color(0xFF101726)
val SurfaceElevated = Color(0xFF172238)
val SurfaceCard = Color(0xFF1D283E)
val SurfaceBorder = Color(0xFF2B3A58)

// Trading Candlestick & Confluence Colors
val BullGreen = Color(0xFF00E676)
val BullGreenDim = Color(0x2E00E676)
val BearRed = Color(0xFFFF3D57)
val BearRedDim = Color(0x2EFF3D57)

// Liquidity & Heatmap Spectrum Colors
val LiquidityCyan = Color(0xFF00E5FF)
val LiquidityGold = Color(0xFFFFD600)
val LiquidityOrange = Color(0xFFFF9100)
val LiquidityPurple = Color(0xFF7C4DFF)
val LiquidityHeatMax = Color(0xFFFF1744)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Accent Colors
val AccentPrimary = Color(0xFF2979FF)
val AccentPrimaryDim = Color(0x332979FF)
val AccentWarning = Color(0xFFFFAB00)
val AccentSuccess = Color(0xFF00C853)

