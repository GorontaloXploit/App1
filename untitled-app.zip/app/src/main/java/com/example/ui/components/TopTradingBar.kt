package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MultiTfConfluence
import com.example.data.model.TradingPair
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TopTradingBar(
    pair: TradingPair,
    availablePairs: List<TradingPair>,
    confluence: MultiTfConfluence,
    onSelectPair: (TradingPair) -> Unit,
    onAutoScanAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        color = SurfaceDark,
        modifier = modifier
            .fillMaxWidth()
            .testTag("top_trading_bar")
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Crypto Pair Selector Dropdown
                Box {
                    Row(
                        modifier = Modifier
                            .clickable { expanded = true }
                            .background(SurfaceElevated, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Coin badge
                        val coinColor = when (pair.symbol) {
                            "BTCUSDT" -> Color(0xFFF7931A)
                            "ETHUSDT" -> Color(0xFF627EEA)
                            "SOLUSDT" -> Color(0xFF14F195)
                            "BNBUSDT" -> Color(0xFFF3BA2F)
                            "XRPUSDT" -> Color(0xFF23292F)
                            "DOGEUSDT" -> Color(0xFFC2A633)
                            else -> AccentPrimary
                        }
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(coinColor, androidx.compose.foundation.shape.CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pair.symbol.take(1),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = pair.symbol,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextPrimary
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Pilih Koin Kripto",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Text(
                                text = "${pair.name} • ${pair.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.5.sp
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(SurfaceElevated)
                    ) {
                        availablePairs.forEach { p ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(p.symbol, fontWeight = FontWeight.Bold, color = TextPrimary)
                                            Text("${p.name} (${p.category})", fontSize = 11.sp, color = TextMuted)
                                        }
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "$${String.format(Locale.US, "%,.${p.pipPrecision}f", p.currentPrice)}",
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "${if (p.change24h >= 0) "+" else ""}${p.change24h}%",
                                                color = if (p.change24h >= 0) BullGreen else BearRed,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    onSelectPair(p)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Current Crypto Price & 24h Change
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$${String.format(Locale.US, "%,.${pair.pipPrecision}f", pair.currentPrice)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val isPositive = pair.change24h >= 0
                        Icon(
                            imageVector = if (isPositive) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = if (isPositive) BullGreen else BearRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${if (isPositive) "+" else ""}${pair.change24h}%",
                            color = if (isPositive) BullGreen else BearRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Quick Confluence Pill & Scan Action
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = when {
                            confluence.confluenceScore >= 75 -> BullGreenDim
                            confluence.confluenceScore >= 50 -> AccentWarning.copy(alpha = 0.15f)
                            else -> BearRedDim
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${confluence.confluenceScore}% Konfluensi",
                            color = when {
                                confluence.confluenceScore >= 75 -> BullGreen
                                confluence.confluenceScore >= 50 -> AccentWarning
                                else -> BearRed
                            },
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onAutoScanAll,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Scan Ulang Semua TF Crypto",
                            tint = AccentPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Crypto Telemetry Row (Funding Rate, 24h Volume, Open Interest)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Funding: ${if (pair.fundingRate >= 0) "+" else ""}${String.format(Locale.US, "%.4f", pair.fundingRate)}%",
                    color = if (pair.fundingRate >= 0) BullGreen else BearRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "24h Vol: ${pair.volume24hUsd}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
                Text(
                    text = "OI: ${pair.openInterest}",
                    color = TextSecondary,
                    fontSize = 10.sp
                )
                Text(
                    text = pair.networkType,
                    color = AccentPrimary,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
