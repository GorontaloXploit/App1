package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.abs

@Composable
fun LiquidityHeatmapScreen(
    pair: TradingPair,
    liquidityLevels: List<LiquidityLevel>,
    modifier: Modifier = Modifier
) {
    var selectedLevel by remember { mutableStateOf<LiquidityLevel?>(liquidityLevels.firstOrNull()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgObsidian)
            .padding(16.dp)
            .testTag("liquidity_heatmap_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(LiquidityCyan.copy(alpha = 0.18f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Layers,
                                    contentDescription = null,
                                    tint = LiquidityCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Liquidity Heatmap Scanner",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Konsentrasi Likuiditas & Order Pool ${pair.symbol}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Surface(
                            color = SurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
                        ) {
                            Text(
                                text = "Live Depth",
                                color = BullGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Heatmap mengidentifikasi area 'Order Rest' (Stop Loss trader retail, Breakout Orders & Liquidation Pool). Harga memiliki gravitasi tinggi bergerak menuju area likuiditas pekat sebelum berbalik arah sesuai bias Multi-TF.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // 2. Visual Heatmap Canvas & Depth Spectrum
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Visual Heatmap Density Spectrum",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Harga: ${pair.currentPrice}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = AccentPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Spectrum bar legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Rendah", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color(0xFF0D47A1),
                                            LiquidityCyan,
                                            LiquidityGold,
                                            LiquidityOrange,
                                            LiquidityHeatMax
                                        )
                                    )
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sangat Padat (Hot Pool)", style = MaterialTheme.typography.labelSmall, color = LiquidityHeatMax, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Dedicated Heatmap Depth Ladder Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(SurfaceElevated, RoundedCornerShape(10.dp))
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                    ) {
                        val maxP = liquidityLevels.maxOfOrNull { it.price } ?: (pair.currentPrice * 1.02)
                        val minP = liquidityLevels.minOfOrNull { it.price } ?: (pair.currentPrice * 0.98)
                        val span = (maxP - minP).coerceAtLeast(0.0001)

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            fun toY(p: Double): Float {
                                val norm = (p - minP) / span
                                return (h - (norm * h)).toFloat()
                            }

                            // Render heat zones across depth
                            liquidityLevels.forEach { lvl ->
                                val ly = toY(lvl.price)
                                val bandColor = when {
                                    lvl.intensity > 0.85f -> LiquidityHeatMax
                                    lvl.intensity > 0.70f -> LiquidityOrange
                                    lvl.intensity > 0.50f -> LiquidityGold
                                    else -> LiquidityCyan
                                }

                                // Heat aura gradient
                                drawRect(
                                    brush = Brush.horizontalGradient(
                                        listOf(
                                            bandColor.copy(alpha = 0.05f),
                                            bandColor.copy(alpha = 0.35f * lvl.intensity),
                                            bandColor.copy(alpha = 0.65f * lvl.intensity)
                                        )
                                    ),
                                    topLeft = Offset(0f, ly - 12f),
                                    size = Size(w, 24f)
                                )

                                // Center intensity line
                                drawLine(
                                    color = bandColor,
                                    start = Offset(0f, ly),
                                    end = Offset(w, ly),
                                    strokeWidth = 2f
                                )
                            }

                            // Current price line indicator
                            val curY = toY(pair.currentPrice)
                            if (curY in 0f..h) {
                                drawLine(
                                    color = Color.White,
                                    start = Offset(0f, curY),
                                    end = Offset(w, curY),
                                    strokeWidth = 2f,
                                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                                )
                            }
                        }

                        // Labels overlay on Canvas
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "▲ Short Liquidation Pool (BSL / Squeeze Magnet)",
                                color = LiquidityGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "— Harga Live: $${String.format(Locale.US, "%,.${pair.pipPrecision}f", pair.currentPrice)}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.background(SurfaceDark.copy(alpha = 0.8f), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                            Text(
                                text = "▼ Long Liquidation Pool (SSL / Cascade Magnet)",
                                color = LiquidityCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 3. Detailed Liquidity Clusters List
        item {
            Text(
                text = "Pool Likuiditas & Klaster Leverage (${liquidityLevels.size} Area)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(liquidityLevels) { level ->
            val isSelected = selectedLevel?.id == level.id
            val distance = level.price - pair.currentPrice
            val isAbove = distance > 0
            val percentDiff = abs(distance / pair.currentPrice) * 100.0

            val badgeColor = when (level.type) {
                LiquidityType.SHORT_LIQUIDATION, LiquidityType.EQUAL_HIGHS -> LiquidityGold
                LiquidityType.LONG_LIQUIDATION, LiquidityType.EQUAL_LOWS -> LiquidityCyan
                LiquidityType.LEVERAGE_HOTSPOT -> LiquidityHeatMax
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) SurfaceElevated else SurfaceDark
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSelected) 1.5.dp else 1.dp,
                    if (isSelected) badgeColor else SurfaceBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedLevel = level }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(badgeColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = level.type.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = SurfaceElevated,
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
                            ) {
                                Text(
                                    text = level.leverageTier,
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = badgeColor.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "$${level.estimatedVolumeMillions}M",
                                    color = badgeColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Level: $${String.format(Locale.US, "%,.${pair.pipPrecision}f", level.price)}",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${if (isAbove) "+ " else "- "}${String.format(Locale.US, "%.2f", percentDiff)}% ($${String.format(Locale.US, "%.2f", abs(distance))})",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isAbove) LiquidityGold else LiquidityCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Progress bar showing heat density
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Intensitas Likuiditas: ${(level.intensity * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                            Text(
                                text = if (level.intensity > 0.8f) "Magnet Squeeze / Flush Kuat" else "Kerapatan Sedang",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (level.intensity > 0.8f) LiquidityHeatMax else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { level.intensity },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = badgeColor,
                            trackColor = SurfaceElevated
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = level.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        // 4. Strategy Confluence Tip
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AccentPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Korelasi Heatmap dengan Multi-Timeframe",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "1. Gunakan D1 & H4 untuk menentukan apakah BSL (atas) atau SSL (bawah) yang akan disapu terlebih dahulu.\n2. Jika D1 Bullish dan H1 membentuk Bullish CHoCH, tunggu sweep ke SSL di bawah swing low M15 sebelum mengambil Entry Buy Limit.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
