package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MultiTfConfluenceScreen(
    pair: TradingPair,
    confluence: MultiTfConfluence,
    analysesMap: Map<TimeFrame, TimeframeAnalysis>,
    onSaveToJournal: (notes: String) -> Unit,
    onNavigateToTimeframe: (TimeFrame) -> Unit,
    modifier: Modifier = Modifier
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var userNoteText by remember { mutableStateOf("") }
    var saveSuccessMessage by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgObsidian)
            .padding(16.dp)
            .testTag("multi_tf_confluence_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Confluence Header Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val scoreColor = when {
                        confluence.confluenceScore >= 75 -> BullGreen
                        confluence.confluenceScore >= 50 -> AccentWarning
                        else -> BearRed
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Penyatuan Analisa 4 Time Frame",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Sintesis D1 (9B) + H4 (3B) + H1 (4M) + M15 (Entry)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        // Confluence Score Circle Badge
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(scoreColor.copy(alpha = 0.15f), CircleShape)
                                .border(2.dp, scoreColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${confluence.confluenceScore}%",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = scoreColor
                                )
                                Text(
                                    text = "SKOR",
                                    fontSize = 8.sp,
                                    color = TextMuted,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LinearProgressIndicator(
                        progress = { confluence.confluenceScore / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = scoreColor,
                        trackColor = SurfaceElevated
                    )
                }
            }
        }

        // 2. Actionable Setup Signal Card
        item {
            val isBullish = confluence.direction.contains("BUY")
            val signalColor = if (isBullish) BullGreen else BearRed

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceElevated),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, signalColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isBullish) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = signalColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = confluence.direction,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = signalColor
                            )
                        }

                        Surface(
                            color = SurfaceDark,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
                        ) {
                            Text(
                                text = "R:R  ${confluence.riskRewardRatio}",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Price Execution Levels Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LevelBox(
                            title = "TITIK ENTRY",
                            value = "$${String.format(Locale.US, "%,.${pair.pipPrecision}f", confluence.entryPrice)}",
                            color = AccentPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        LevelBox(
                            title = "STOP LOSS (SL)",
                            value = "$${String.format(Locale.US, "%,.${pair.pipPrecision}f", confluence.stopLoss)}",
                            color = BearRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LevelBox(
                            title = "TARGET TP 1",
                            value = "$${String.format(Locale.US, "%,.${pair.pipPrecision}f", confluence.takeProfit1)}",
                            color = BullGreen,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        LevelBox(
                            title = "TARGET TP 2 (H4)",
                            value = "$${String.format(Locale.US, "%,.${pair.pipPrecision}f", confluence.takeProfit2)}",
                            color = LiquidityGold,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = confluence.recommendedAction,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { showSaveDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_setup_button")
                    ) {
                        Icon(imageVector = Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simpan Sinyal ke Jurnal Trading", fontWeight = FontWeight.Bold)
                    }

                    if (saveSuccessMessage) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "✓ Berhasil disimpan ke Jurnal Trading!",
                            color = BullGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 3. Breakdown per Timeframe
        item {
            Text(
                text = "Pencocokan Peran 4 Time Frame",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        // TF D1 Item
        item {
            val d1Analysis = analysesMap[TimeFrame.D1]
            TimeFrameConfluenceCard(
                timeframe = TimeFrame.D1,
                roleTitle = "Bias Siklus Makro (Data 9 Bulan)",
                roleDesc = "Menganalisa arah tren utama & siklus akumulasi/distribusi.",
                isAligned = confluence.isD1Aligned,
                analysisSnippet = d1Analysis?.summary ?: "Bias Bullish terkonfirmasi.",
                detailText = d1Analysis?.structureNote ?: "",
                badge = d1Analysis?.bias?.label ?: "BULLISH 🟢",
                badgeColor = BullGreen,
                onClick = { onNavigateToTimeframe(TimeFrame.D1) }
            )
        }

        // TF H4 Item
        item {
            val h4Analysis = analysesMap[TimeFrame.H4]
            TimeFrameConfluenceCard(
                timeframe = TimeFrame.H4,
                roleTitle = "Zona Penting & Target (Data 3 Bulan)",
                roleDesc = "Area Supply & Demand yang ditargetkan harga berdasarkan bias D1.",
                isAligned = confluence.isH4Aligned,
                analysisSnippet = h4Analysis?.keyZoneText ?: "Area Demand H4 aktif diretest.",
                detailText = h4Analysis?.summary ?: "",
                badge = "Zona Target H4",
                badgeColor = AccentPrimary,
                onClick = { onNavigateToTimeframe(TimeFrame.H4) }
            )
        }

        // TF H1 Item
        item {
            val h1Analysis = analysesMap[TimeFrame.H1]
            TimeFrameConfluenceCard(
                timeframe = TimeFrame.H1,
                roleTitle = "Struktur Pasar (Data 4 Minggu)",
                roleDesc = "Menentukan struktur pasar (BOS/CHoCH) berdasarkan D1 dan H4.",
                isAligned = confluence.isH1Aligned,
                analysisSnippet = h1Analysis?.structureNote ?: "Bullish CHoCH terkonfirmasi.",
                detailText = h1Analysis?.keyZoneText ?: "",
                badge = h1Analysis?.structure?.label ?: "Bullish BOS",
                badgeColor = LiquidityCyan,
                onClick = { onNavigateToTimeframe(TimeFrame.H1) }
            )
        }

        // TF M15 Item
        item {
            val m15Analysis = analysesMap[TimeFrame.M15]
            TimeFrameConfluenceCard(
                timeframe = TimeFrame.M15,
                roleTitle = "Titik Masuk Presisi (TF 15 Menit)",
                roleDesc = "Mencari titik masuk berdasarkan gabungan dari ke-3 data TF sebelumnya.",
                isAligned = confluence.isM15Aligned,
                analysisSnippet = m15Analysis?.keyZoneText ?: "Order Block M15 siap dieksekusi.",
                detailText = m15Analysis?.summary ?: "",
                badge = "Entry Trigger Ready",
                badgeColor = LiquidityGold,
                onClick = { onNavigateToTimeframe(TimeFrame.M15) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Save Setup Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Simpan Sinyal Trading ke Jurnal", color = TextPrimary) },
            text = {
                Column {
                    Text(
                        text = "Simpan analisa ${pair.symbol} dengan probabilitas konfluensi ${confluence.confluenceScore}% ke dalam basis data Room.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = userNoteText,
                        onValueChange = { userNoteText = it },
                        label = { Text("Catatan Tambahan (Opsional)") },
                        placeholder = { Text("Contoh: Entry saat retest London Session") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentPrimary,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveToJournal(userNoteText)
                        showSaveDialog = false
                        saveSuccessMessage = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            },
            containerColor = SurfaceDark
        )
    }
}

@Composable
private fun LevelBox(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SurfaceDark,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun TimeFrameConfluenceCard(
    timeframe: TimeFrame,
    roleTitle: String,
    roleDesc: String,
    isAligned: Boolean,
    analysisSnippet: String,
    detailText: String,
    badge: String,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isAligned) BullGreen.copy(alpha = 0.5f) else SurfaceBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = AccentPrimaryDim,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = timeframe.code,
                            color = AccentPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = roleTitle,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = roleDesc,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Icon(
                    imageVector = if (isAligned) Icons.Default.CheckCircle else Icons.Default.Pending,
                    contentDescription = null,
                    tint = if (isAligned) BullGreen else AccentWarning,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                color = SurfaceElevated,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = badge,
                            color = badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = onClick,
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("Buka Grafik TF >", fontSize = 11.sp, color = AccentPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = analysisSnippet,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontSize = 11.5.sp
                    )
                    if (detailText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = detailText,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }
        }
    }
}
