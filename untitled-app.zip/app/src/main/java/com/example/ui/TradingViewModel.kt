package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MarketDataProvider
import com.example.data.TradingRepository
import com.example.data.local.AppDatabase
import com.example.data.local.SavedSetupEntity
import com.example.data.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ViewMode(val label: String) {
    CHART("Grafik Multi-TF"),
    HEATMAP("Liquidity Heatmap"),
    CONFLUENCE("Penyatuan Sinyal"),
    JOURNAL("Jurnal Trading")
}

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TradingRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = TradingRepository(db.analysisDao())
    }

    companion object {
        fun provideFactory(application: Application): androidx.lifecycle.ViewModelProvider.Factory =
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                    return TradingViewModel(application) as T
                }
            }
    }

    val availablePairs = TradingPair.DEFAULT_PAIRS

    private val _selectedPair = MutableStateFlow(availablePairs.first())
    val selectedPair: StateFlow<TradingPair> = _selectedPair.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(TimeFrame.D1)
    val selectedTimeframe: StateFlow<TimeFrame> = _selectedTimeframe.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.CHART)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    // Candlesticks for current pair + timeframe
    val candles: StateFlow<List<Candle>> = combine(_selectedPair, _selectedTimeframe) { pair, tf ->
        MarketDataProvider.generateCandles(pair, tf)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Zones for current pair + timeframe
    val zones: StateFlow<List<TradingZone>> = combine(_selectedPair, _selectedTimeframe) { pair, tf ->
        MarketDataProvider.getZonesForTimeframe(pair, tf)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Liquidity levels for heatmap
    val liquidityLevels: StateFlow<List<LiquidityLevel>> = _selectedPair.map { pair ->
        MarketDataProvider.getLiquidityLevels(pair)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Preserved multi-timeframe analyses from Room DB
    val analysesMap: StateFlow<Map<TimeFrame, TimeframeAnalysis>> = _selectedPair.flatMapLatest { pair ->
        repository.getAnalysesForPair(pair)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Multi-TF Confluence calculation unifying D1 + H4 + H1 + M15
    val confluence: StateFlow<MultiTfConfluence> = combine(
        _selectedPair,
        analysesMap
    ) { pair, map ->
        val d1 = map[TimeFrame.D1] ?: MarketDataProvider.getDefaultTimeframeAnalysis(pair, TimeFrame.D1)
        val h4 = map[TimeFrame.H4] ?: MarketDataProvider.getDefaultTimeframeAnalysis(pair, TimeFrame.H4)
        val h1 = map[TimeFrame.H1] ?: MarketDataProvider.getDefaultTimeframeAnalysis(pair, TimeFrame.H1)
        val m15 = map[TimeFrame.M15] ?: MarketDataProvider.getDefaultTimeframeAnalysis(pair, TimeFrame.M15)
        MarketDataProvider.computeMultiTfConfluence(pair, d1, h4, h1, m15)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MarketDataProvider.computeMultiTfConfluence(
            availablePairs.first(),
            MarketDataProvider.getDefaultTimeframeAnalysis(availablePairs.first(), TimeFrame.D1),
            MarketDataProvider.getDefaultTimeframeAnalysis(availablePairs.first(), TimeFrame.H4),
            MarketDataProvider.getDefaultTimeframeAnalysis(availablePairs.first(), TimeFrame.H1),
            MarketDataProvider.getDefaultTimeframeAnalysis(availablePairs.first(), TimeFrame.M15)
        )
    )

    // Saved trade setups journal
    val savedSetups: StateFlow<List<SavedSetupEntity>> = repository.savedSetups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectPair(pair: TradingPair) {
        _selectedPair.value = pair
    }

    fun selectTimeframe(tf: TimeFrame) {
        _selectedTimeframe.value = tf
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun updateAnalysis(analysis: TimeframeAnalysis) {
        viewModelScope.launch {
            repository.saveAnalysis(analysis)
        }
    }

    fun autoScanAndSaveCurrentTimeframe() {
        val pair = _selectedPair.value
        val tf = _selectedTimeframe.value
        val freshAnalysis = MarketDataProvider.getDefaultTimeframeAnalysis(pair, tf)
        viewModelScope.launch {
            repository.saveAnalysis(freshAnalysis)
        }
    }

    fun autoScanAllTimeframes() {
        val pair = _selectedPair.value
        viewModelScope.launch {
            TimeFrame.values().forEach { tf ->
                val fresh = MarketDataProvider.getDefaultTimeframeAnalysis(pair, tf)
                repository.saveAnalysis(fresh)
            }
        }
    }

    fun saveCurrentConfluenceToJournal(userNotes: String = "") {
        val conf = confluence.value
        val entity = SavedSetupEntity(
            pairSymbol = conf.pairSymbol,
            signalType = conf.direction,
            confluenceScore = conf.confluenceScore,
            entryPrice = conf.entryPrice,
            stopLoss = conf.stopLoss,
            takeProfit1 = conf.takeProfit1,
            takeProfit2 = conf.takeProfit2,
            riskReward = conf.riskRewardRatio,
            d1Bias = conf.d1BiasAnalysis,
            h4Target = conf.h4TargetZoneAnalysis,
            h1Structure = conf.h1StructureAnalysis,
            m15Trigger = conf.m15EntryTriggerAnalysis,
            notes = userNotes
        )
        viewModelScope.launch {
            repository.saveSetup(entity)
        }
    }

    fun deleteJournalEntry(id: Long) {
        viewModelScope.launch {
            repository.deleteSetup(id)
        }
    }
}
