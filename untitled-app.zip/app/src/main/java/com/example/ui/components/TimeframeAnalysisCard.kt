package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun TimeframeAnalysisCard(
    timeframe: TimeFrame,
    analysis: TimeframeAnalysis?,
    pair: TradingPair,
    onUpdateAnalysis: (TimeframeAnalysis) -> Unit,
    onAutoScan: () -> Unit,
    onOpenConfluence: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditing by remember { mutableStateOf(false) }

    val currentBias = analysis?.bias ?: MarketBias.BULLISH
    val currentStructure = analysis?.structure ?: StructureStatus.BULLISH_BOS
    var editZoneText by remember(analysis) { mutableStateOf(analysis?.keyZoneText ?: "") }
    var editNoteText by remember(analysis) { mutableStateOf(analysis?.structureNote ?: "") }
    var editBias by remember(analysis) { mutableStateOf(currentBias) }
    var editStructure by remember(analysis) { mutableStateOf(currentStructure) }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("timeframe_analysis_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Role & Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AccentPrimaryDim,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = timeframe.code,
                                color = AccentPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = timeframe.role,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Data Grafik: ${timeframe.periodSpan}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onAutoScan,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = "Analisa Otomatis",
                            tint = LiquidityCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { isEditing = !isEditing },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditing) Icons.Default.Check else Icons.Default.Edit,
                            contentDescription = "Edit Analisa",
                            tint = AccentPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Explanation of role for this specific TF
            Surface(
                color = SurfaceElevated,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TipsAndUpdates,
                        contentDescription = null,
                        tint = LiquidityGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = timeframe.roleExplanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (!isEditing) {
                // View Mode
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Status Analisa Tersimpan:",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Surface(
                            color = if (currentBias == MarketBias.BULLISH) BullGreenDim else BearRedDim,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = currentBias.label,
                                color = if (currentBias == MarketBias.BULLISH) BullGreen else BearRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (analysis != null) {
                        Surface(
                            color = SurfaceCard,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = analysis.summary,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = analysis.keyZoneText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AccentPrimary,
                                    fontSize = 11.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = analysis.structureNote,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Navigation to confluence
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = onOpenConfluence,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp), tint = AccentPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cocokkan dengan TF Lain >", fontSize = 11.5.sp, color = AccentPrimary)
                        }
                    }
                }
            } else {
                // Edit Mode
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Pilih Bias Pasar ${timeframe.code}:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MarketBias.values().forEach { bias ->
                            val isSel = editBias == bias
                            FilterChip(
                                selected = isSel,
                                onClick = { editBias = bias },
                                label = { Text(bias.name, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (bias == MarketBias.BULLISH) BullGreen else BearRed,
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editZoneText,
                        onValueChange = { editZoneText = it },
                        label = { Text("Area Zona Penting / Level Kunci", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentPrimary,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    OutlinedTextField(
                        value = editNoteText,
                        onValueChange = { editNoteText = it },
                        label = { Text("Catatan Analisa Struktur / Trigger", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentPrimary,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isEditing = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Batal", color = TextSecondary)
                        }
                        Button(
                            onClick = {
                                val updated = TimeframeAnalysis(
                                    timeframe = timeframe,
                                    pairSymbol = pair.symbol,
                                    bias = editBias,
                                    structure = editStructure,
                                    keyZoneText = editZoneText,
                                    structureNote = editNoteText,
                                    summary = "Analisa manual ${timeframe.code}: ${editBias.name}",
                                    keyTargetPrice = pair.currentPrice,
                                    isConfirmed = true
                                )
                                onUpdateAnalysis(updated)
                                isEditing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Simpan Perubahan")
                        }
                    }
                }
            }
        }
    }
}
