package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    zones: List<TradingZone>,
    liquidityLevels: List<LiquidityLevel>,
    pair: TradingPair,
    timeframe: TimeFrame,
    showLiquidityOverlay: Boolean = true,
    showZonesOverlay: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(SurfaceDark, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = AccentPrimary, modifier = Modifier.size(36.dp))
        }
        return
    }

    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }

    // Direct use of candles list (standard optimized 35-50 candles)
    val visibleCandles = candles
    val totalCandles = visibleCandles.size

    val minPrice = visibleCandles.minOfOrNull { it.low } ?: (pair.currentPrice * 0.98)
    val maxPrice = visibleCandles.maxOfOrNull { it.high } ?: (pair.currentPrice * 1.02)
    val pricePadding = ((maxPrice - minPrice) * 0.08).coerceAtLeast(pair.currentPrice * 0.005)
    val chartMin = minPrice - pricePadding
    val chartMax = maxPrice + pricePadding
    val priceSpan = (chartMax - chartMin).coerceAtLeast(0.0001)

    val inspected = selectedCandleIndex?.let { idx ->
        visibleCandles.getOrNull(idx)
    } ?: visibleCandles.lastOrNull()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(14.dp))
            .padding(10.dp)
            .testTag("candlestick_chart_container")
    ) {
        // 1. Chart Header with Candle OHLC Inspection and Role Badge
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (inspected != null) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = inspected.timeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (inspected.isBullish) "▲ NAIK" else "▼ TURUN",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (inspected.isBullish) BullGreen else BearRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "O:${inspected.open} H:${inspected.high} L:${inspected.low} C:${inspected.close}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = if (inspected.isBullish) BullGreen else BearRed,
                        fontSize = 11.sp
                    )
                }
            }

            // Timeframe badge
            Surface(
                color = AccentPrimary.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${timeframe.code} • ${timeframe.periodSpan}",
                    color = AccentPrimary,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }

        // 2. Main Chart Area (Canvas + Overlay Price Scale)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(visibleCandles) {
                        detectDragGestures(
                            onDrag = { change, _ ->
                                change.consume()
                                val candleWidth = size.width / totalCandles.coerceAtLeast(1)
                                val relIdx = (change.position.x / candleWidth).toInt().coerceIn(0, totalCandles - 1)
                                selectedCandleIndex = relIdx
                            },
                            onDragEnd = {
                                selectedCandleIndex = null
                            }
                        )
                    }
                    .pointerInput(visibleCandles) {
                        detectTapGestures { offset ->
                            val candleWidth = size.width / totalCandles.coerceAtLeast(1)
                            val relIdx = (offset.x / candleWidth).toInt().coerceIn(0, totalCandles - 1)
                            selectedCandleIndex = relIdx
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val candleSlotWidth = canvasWidth / totalCandles.coerceAtLeast(1)
                val bodyWidth = (candleSlotWidth * 0.70f).coerceIn(2.5f, 16f)

                fun priceToY(price: Double): Float {
                    val normalized = ((price - chartMin) / priceSpan).toFloat()
                    return canvasHeight - (normalized * canvasHeight)
                }

                // A. Background Grid Lines
                val gridSteps = 4
                for (g in 0..gridSteps) {
                    val y = (canvasHeight * g) / gridSteps
                    drawLine(
                        color = SurfaceBorder.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )
                }

                // B. Supply & Demand Zones Overlay
                if (showZonesOverlay) {
                    zones.forEach { zone ->
                        val topY = priceToY(max(zone.priceTop, zone.priceBottom))
                        val bottomY = priceToY(min(zone.priceTop, zone.priceBottom))
                        val zoneH = max(bottomY - topY, 8f)

                        val zoneColor = if (zone.type.isDemandOrSupport) {
                            BullGreen.copy(alpha = 0.16f)
                        } else {
                            BearRed.copy(alpha = 0.16f)
                        }
                        val borderColor = if (zone.type.isDemandOrSupport) {
                            BullGreen.copy(alpha = 0.55f)
                        } else {
                            BearRed.copy(alpha = 0.55f)
                        }

                        drawRect(
                            color = zoneColor,
                            topLeft = Offset(0f, topY),
                            size = Size(canvasWidth, zoneH)
                        )
                        drawLine(
                            color = borderColor,
                            start = Offset(0f, topY),
                            end = Offset(canvasWidth, topY),
                            strokeWidth = 1.2f
                        )
                        drawLine(
                            color = borderColor,
                            start = Offset(0f, bottomY),
                            end = Offset(canvasWidth, bottomY),
                            strokeWidth = 1.2f
                        )
                    }
                }

                // C. Liquidity Clusters / Heat Bands
                if (showLiquidityOverlay) {
                    liquidityLevels.forEach { liq ->
                        val ly = priceToY(liq.price)
                        if (ly in 0f..canvasHeight) {
                            val liqColor = when (liq.type) {
                                LiquidityType.SHORT_LIQUIDATION, LiquidityType.EQUAL_HIGHS -> LiquidityGold
                                LiquidityType.LONG_LIQUIDATION, LiquidityType.EQUAL_LOWS -> LiquidityCyan
                                LiquidityType.LEVERAGE_HOTSPOT -> LiquidityHeatMax
                            }

                            drawRect(
                                color = liqColor.copy(alpha = 0.14f * liq.intensity),
                                topLeft = Offset(0f, ly - 5f),
                                size = Size(canvasWidth, 10f)
                            )
                            drawLine(
                                color = liqColor.copy(alpha = 0.65f),
                                start = Offset(0f, ly),
                                end = Offset(canvasWidth, ly),
                                strokeWidth = 1.2f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 5f), 0f)
                            )
                        }
                    }
                }

                // D. Volume Bars at Bottom
                val maxVol = visibleCandles.maxOfOrNull { it.volume } ?: 1.0
                val volumeAreaHeight = canvasHeight * 0.16f
                visibleCandles.forEachIndexed { i, candle ->
                    val cx = (i * candleSlotWidth) + (candleSlotWidth / 2f)
                    val volHeight = ((candle.volume / maxVol) * volumeAreaHeight).toFloat()
                    val volColor = if (candle.isBullish) BullGreen.copy(alpha = 0.28f) else BearRed.copy(alpha = 0.28f)
                    drawRect(
                        color = volColor,
                        topLeft = Offset(cx - (bodyWidth / 2f), canvasHeight - volHeight),
                        size = Size(bodyWidth, volHeight)
                    )
                }

                // E. Candlestick Bars (Wick & Body)
                visibleCandles.forEachIndexed { i, candle ->
                    val cx = (i * candleSlotWidth) + (candleSlotWidth / 2f)
                    val highY = priceToY(candle.high)
                    val lowY = priceToY(candle.low)
                    val openY = priceToY(candle.open)
                    val closeY = priceToY(candle.close)

                    val candleColor = if (candle.isBullish) BullGreen else BearRed
                    val bodyTop = min(openY, closeY)
                    val bodyHeight = max(abs(closeY - openY), 1.5f)

                    // Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(cx, highY),
                        end = Offset(cx, lowY),
                        strokeWidth = 1.2f
                    )
                    // Body
                    drawRect(
                        color = candleColor,
                        topLeft = Offset(cx - (bodyWidth / 2f), bodyTop),
                        size = Size(bodyWidth, bodyHeight)
                    )
                }

                // F. Current Price Marker Line
                val currentPriceY = priceToY(pair.currentPrice)
                if (currentPriceY in 0f..canvasHeight) {
                    drawLine(
                        color = AccentPrimary,
                        start = Offset(0f, currentPriceY),
                        end = Offset(canvasWidth, currentPriceY),
                        strokeWidth = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                    )
                }

                // G. Touch Scrubber Crosshair
                selectedCandleIndex?.let { selIdx ->
                    if (selIdx in 0 until totalCandles) {
                        val selCandle = visibleCandles[selIdx]
                        val sx = (selIdx * candleSlotWidth) + (candleSlotWidth / 2f)
                        val sy = priceToY(selCandle.close)

                        drawLine(
                            color = Color.White.copy(alpha = 0.5f),
                            start = Offset(sx, 0f),
                            end = Offset(sx, canvasHeight),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )
                        drawLine(
                            color = Color.White.copy(alpha = 0.5f),
                            start = Offset(0f, sy),
                            end = Offset(canvasWidth, sy),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )
                    }
                }
            }

            // 3. Price Scale Overlay on the Right (Pure Compose Text for safety & 0 font crashes)
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .align(Alignment.CenterEnd)
                    .padding(end = 4.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                val gridSteps = 4
                for (g in gridSteps downTo 0) {
                    val p = chartMin + (priceSpan * (g.toDouble() / gridSteps))
                    Text(
                        text = String.format(Locale.US, "%.${pair.pipPrecision}f", p),
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .background(SurfaceDark.copy(alpha = 0.7f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 4. Timeframe Role & Strategy Explainer Bar
        Surface(
            color = SurfaceElevated,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                when (timeframe) {
                                    TimeFrame.D1 -> AccentPrimary
                                    TimeFrame.H4 -> LiquidityGold
                                    TimeFrame.H1 -> LiquidityCyan
                                    TimeFrame.M15 -> BullGreen
                                },
                                RoundedCornerShape(4.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${timeframe.role}: ${timeframe.roleExplanation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 10.5.sp,
                        maxLines = 2
                    )
                }
            }
        }
    }
}
