package com.example.data

import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object MarketDataProvider {

    /**
     * Generates correlated multi-timeframe candlestick data for a pair.
     * The lower timeframes are mathematically consistent with higher timeframes.
     */
    fun generateCandles(pair: TradingPair, timeframe: TimeFrame): List<Candle> {
        val count = when (timeframe) {
            TimeFrame.D1 -> 50 // Standard optimal count (menampilkan data siklus 9 bulan)
            TimeFrame.H4 -> 45 // Standard optimal count (menampilkan area zona 3 bulan)
            TimeFrame.H1 -> 40 // Standard optimal count (menampilkan struktur pasar 4 minggu)
            TimeFrame.M15 -> 35 // Standard optimal count (menampilkan trigger titik masuk M15)
        }

        val basePrice = pair.currentPrice
        val volatility = when (pair.symbol) {
            "BTCUSDT" -> 850.0
            "ETHUSDT" -> 48.0
            "SOLUSDT" -> 3.2
            "BNBUSDT" -> 8.5
            "XRPUSDT" -> 0.012
            "DOGEUSDT" -> 0.0035
            else -> pair.currentPrice * 0.015
        }

        val timeStepMillis = when (timeframe) {
            TimeFrame.D1 -> (270L * 24 * 60 * 60 * 1000) / 50 // Span ~9 bulan
            TimeFrame.H4 -> (90L * 24 * 60 * 60 * 1000) / 45  // Span ~3 bulan
            TimeFrame.H1 -> (28L * 24 * 60 * 60 * 1000) / 40  // Span ~4 minggu
            TimeFrame.M15 -> 15L * 60 * 1000                  // Intraday 15 menit
        }

        val dateFormat = when (timeframe) {
            TimeFrame.D1 -> SimpleDateFormat("dd MMM yy", Locale.getDefault())
            TimeFrame.H4 -> SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
            TimeFrame.H1 -> SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            TimeFrame.M15 -> SimpleDateFormat("HH:mm", Locale.getDefault())
        }

        val now = System.currentTimeMillis()
        val candles = mutableListOf<Candle>()

        // Deterministic pseudo-random seed per crypto pair and timeframe
        val random = Random(pair.symbol.hashCode().toLong() + timeframe.ordinal * 997L)

        // Generate macro crypto trend curve
        var current = when (timeframe) {
            TimeFrame.D1 -> basePrice * 0.88 // 9 months accumulation base
            TimeFrame.H4 -> basePrice * 0.94 // 3 months consolidation
            TimeFrame.H1 -> basePrice * 0.97 // 4 weeks swing
            TimeFrame.M15 -> basePrice * 0.992 // recent session
        }

        for (i in 0 until count) {
            val progress = i.toDouble() / count.toDouble()
            // Macro trend drift + wave cycle
            val trendDrift = (basePrice - current) * 0.025
            val cycle = sin(progress * 4.0 * Math.PI) * volatility * 1.5
            val noise = (random.nextDouble() - 0.48) * volatility

            val open = current
            var close = open + trendDrift + (noise * 0.5)
            if (i == count - 1) {
                close = basePrice // latest candle ends on current live price
            }

            val high = max(open, close) + (random.nextDouble() * volatility * 0.7)
            val low = min(open, close) - (random.nextDouble() * volatility * 0.7)
            val volume = 15000.0 + random.nextDouble() * 45000.0 * (1.0 + abs(close - open) / volatility)

            val timestamp = now - ((count - 1 - i) * timeStepMillis)
            val timeLabel = dateFormat.format(Date(timestamp))

            candles.add(
                Candle(
                    id = i,
                    timestamp = timestamp,
                    timeLabel = timeLabel,
                    open = roundToPrecision(open, pair.pipPrecision),
                    high = roundToPrecision(high, pair.pipPrecision),
                    low = roundToPrecision(low, pair.pipPrecision),
                    close = roundToPrecision(close, pair.pipPrecision),
                    volume = volume
                )
            )
            current = close
        }

        return candles
    }

    /**
     * Get Supply & Demand, Support & Resistance, and Liquidation zones for the selected crypto timeframe.
     */
    fun getZonesForTimeframe(pair: TradingPair, timeframe: TimeFrame, candles: List<Candle> = emptyList()): List<TradingZone> {
        val curr = pair.currentPrice
        val delta = when (pair.symbol) {
            "BTCUSDT" -> 1100.0
            "ETHUSDT" -> 65.0
            "SOLUSDT" -> 4.2
            "BNBUSDT" -> 12.0
            "XRPUSDT" -> 0.015
            "DOGEUSDT" -> 0.0045
            else -> pair.currentPrice * 0.018
        }

        return when (timeframe) {
            TimeFrame.D1 -> listOf(
                TradingZone(
                    id = "D1_SUPPLY_1",
                    priceTop = roundToPrecision(curr + (delta * 4.5), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr + (delta * 3.8), pair.pipPrecision),
                    type = ZoneType.SUPPLY,
                    label = "D1 Macro Supply / ATH Resistance (9M)",
                    timeframe = TimeFrame.D1,
                    description = "Area resistance makro 9 bulan dari siklus distribusi institusi & ETF inflow peak."
                ),
                TradingZone(
                    id = "D1_DEMAND_1",
                    priceTop = roundToPrecision(curr - (delta * 1.8), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr - (delta * 2.6), pair.pipPrecision),
                    type = ZoneType.DEMAND,
                    label = "D1 Whale Accumulation Demand Zone",
                    timeframe = TimeFrame.D1,
                    description = "Area fresh demand 9 bulan di mana volume akumulasi on-chain paus terdeteksi masif."
                ),
                TradingZone(
                    id = "D1_SUPPORT_KEY",
                    priceTop = roundToPrecision(curr - (delta * 4.2), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr - (delta * 4.5), pair.pipPrecision),
                    type = ZoneType.SUPPORT,
                    label = "D1 Macro Key Support & 200 EMA",
                    timeframe = TimeFrame.D1,
                    description = "Support kuat siklus makro fondasi bias bullish crypto jangka panjang."
                )
            )

            TimeFrame.H4 -> listOf(
                TradingZone(
                    id = "H4_TARGET_ZONE_1",
                    priceTop = roundToPrecision(curr + (delta * 2.2), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr + (delta * 1.8), pair.pipPrecision),
                    type = ZoneType.SUPPLY,
                    label = "H4 CME Gap & Supply Target",
                    timeframe = TimeFrame.H4,
                    description = "Target utama take profit harga: menutup CME Futures Gap dan area supply 3 bulan."
                ),
                TradingZone(
                    id = "H4_DEMAND_IMPORTANT",
                    priceTop = roundToPrecision(curr - (delta * 0.6), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr - (delta * 1.2), pair.pipPrecision),
                    type = ZoneType.DEMAND,
                    label = "H4 Key Demand Zone (Target Rebound)",
                    timeframe = TimeFrame.H4,
                    description = "Zona penting 3 bulan yang sedang diuji harga crypto untuk mencari pantulan (Demand Bounce)."
                )
            )

            TimeFrame.H1 -> listOf(
                TradingZone(
                    id = "H1_BOS_LEVEL",
                    priceTop = roundToPrecision(curr + (delta * 0.9), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr + (delta * 0.8), pair.pipPrecision),
                    type = ZoneType.RESISTANCE,
                    label = "H1 BOS Resistance / Range High",
                    timeframe = TimeFrame.H1,
                    description = "Level Break of Structure (BOS) H1 untuk konfirmasi kelanjutan tren naik setelah fase akumulasi."
                ),
                TradingZone(
                    id = "H1_DEMAND_OB",
                    priceTop = roundToPrecision(curr - (delta * 0.25), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr - (delta * 0.55), pair.pipPrecision),
                    type = ZoneType.DEMAND,
                    label = "H1 Institutional Order Block (OB)",
                    timeframe = TimeFrame.H1,
                    description = "Struktur Higher Low H1 penahan koreksi internal dengan volume buying tinggi."
                )
            )

            TimeFrame.M15 -> listOf(
                TradingZone(
                    id = "M15_REFINED_OB",
                    priceTop = roundToPrecision(curr + (delta * 0.05), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr - (delta * 0.18), pair.pipPrecision),
                    type = ZoneType.DEMAND,
                    label = "M15 Refined Entry Zone (Liq Sweep OB)",
                    timeframe = TimeFrame.M15,
                    description = "Zona entry presisi setelah liquidity sweep, cocok untuk Long spot maupun leverage futures dengan SL terukur."
                ),
                TradingZone(
                    id = "M15_IMBALANCE",
                    priceTop = roundToPrecision(curr + (delta * 0.65), pair.pipPrecision),
                    priceBottom = roundToPrecision(curr + (delta * 0.55), pair.pipPrecision),
                    type = ZoneType.RESISTANCE,
                    label = "M15 Fair Value Gap (FVG) / TP1",
                    timeframe = TimeFrame.M15,
                    description = "Area ketidakseimbangan order flow (FVG) untuk target take profit pertama."
                )
            )
        }
    }

    /**
     * Generates Crypto Liquidation Heatmap levels showing resting leverage liquidation pools.
     */
    fun getLiquidityLevels(pair: TradingPair): List<LiquidityLevel> {
        val curr = pair.currentPrice
        val delta = when (pair.symbol) {
            "BTCUSDT" -> 1100.0
            "ETHUSDT" -> 65.0
            "SOLUSDT" -> 4.2
            "BNBUSDT" -> 12.0
            "XRPUSDT" -> 0.015
            "DOGEUSDT" -> 0.0045
            else -> pair.currentPrice * 0.018
        }

        return listOf(
            LiquidityLevel(
                id = "LIQ_BSL_HIGH",
                price = roundToPrecision(curr + (delta * 2.8), pair.pipPrecision),
                type = LiquidityType.SHORT_LIQUIDATION,
                intensity = 0.95f,
                estimatedVolumeMillions = when (pair.symbol) {
                    "BTCUSDT" -> 348.5
                    "ETHUSDT" -> 142.0
                    "SOLUSDT" -> 48.6
                    else -> 24.5
                },
                leverageTier = "100x & 50x Shorts",
                description = "Area likuidasi Short sellers leverage tinggi (100x/50x) di atas swing high. Magnet breakout/short squeeze."
            ),
            LiquidityLevel(
                id = "LIQ_EQH_POOL",
                price = roundToPrecision(curr + (delta * 1.5), pair.pipPrecision),
                type = LiquidityType.EQUAL_HIGHS,
                intensity = 0.82f,
                estimatedVolumeMillions = when (pair.symbol) {
                    "BTCUSDT" -> 215.0
                    "ETHUSDT" -> 89.0
                    "SOLUSDT" -> 31.5
                    else -> 15.2
                },
                leverageTier = "25x & 50x Shorts",
                description = "Equal Highs (EQH) Liquidation Pool di bursa Binance & Bybit, menjadi target penarikan harga jangka pendek."
            ),
            LiquidityLevel(
                id = "LIQ_MID_IMBALANCE",
                price = roundToPrecision(curr + (delta * 0.4), pair.pipPrecision),
                type = LiquidityType.LEVERAGE_HOTSPOT,
                intensity = 0.65f,
                estimatedVolumeMillions = when (pair.symbol) {
                    "BTCUSDT" -> 98.4
                    "ETHUSDT" -> 42.1
                    "SOLUSDT" -> 18.0
                    else -> 8.5
                },
                leverageTier = "100x Scalpers",
                description = "Hotspot likuidasi leverage 100x scalper intraday di sekitar Fair Value Gap (FVG)."
            ),
            LiquidityLevel(
                id = "LIQ_SSL_LOW",
                price = roundToPrecision(curr - (delta * 1.2), pair.pipPrecision),
                type = LiquidityType.LONG_LIQUIDATION,
                intensity = 0.88f,
                estimatedVolumeMillions = when (pair.symbol) {
                    "BTCUSDT" -> 280.0
                    "ETHUSDT" -> 115.0
                    "SOLUSDT" -> 39.4
                    else -> 19.8
                },
                leverageTier = "50x & 25x Longs",
                description = "Area likuidasi Longs di bawah swing low 4-Jam. Rawan terjadi liquidity sweep / fake breakdown sebelum ekspansi."
            ),
            LiquidityLevel(
                id = "LIQ_EQL_DEEP",
                price = roundToPrecision(curr - (delta * 2.6), pair.pipPrecision),
                type = LiquidityType.EQUAL_LOWS,
                intensity = 0.92f,
                estimatedVolumeMillions = when (pair.symbol) {
                    "BTCUSDT" -> 410.0
                    "ETHUSDT" -> 185.0
                    "SOLUSDT" -> 62.0
                    else -> 28.5
                },
                leverageTier = "10x & 25x Longs",
                description = "Kolam likuidasi masif (EQL Pool) di bawah Daily Demand makro. Titik invalidasi tren bullish jangka panjang."
            )
        )
    }

    /**
     * Default analysis presets matching the 4 timeframes for crypto.
     */
    fun getDefaultTimeframeAnalysis(pair: TradingPair, timeframe: TimeFrame): TimeframeAnalysis {
        val curr = pair.currentPrice
        val delta = when (pair.symbol) {
            "BTCUSDT" -> 1100.0
            "ETHUSDT" -> 65.0
            "SOLUSDT" -> 4.2
            "BNBUSDT" -> 12.0
            "XRPUSDT" -> 0.015
            "DOGEUSDT" -> 0.0045
            else -> pair.currentPrice * 0.018
        }

        return when (timeframe) {
            TimeFrame.D1 -> TimeframeAnalysis(
                timeframe = TimeFrame.D1,
                pairSymbol = pair.symbol,
                bias = MarketBias.BULLISH,
                structure = StructureStatus.BULLISH_BOS,
                keyZoneText = "Demand Zone 9 Bulan: ${roundToPrecision(curr - delta * 2.0, pair.pipPrecision)} - ${roundToPrecision(curr - delta * 2.5, pair.pipPrecision)}",
                structureNote = "Tren makro D1 9 bulan konsisten membentuk Higher High (HH) sejalan siklus halving & net institutional inflow.",
                summary = "BIAS SIKLUS MAKRO: BULLISH KUAT. Dominasi buyer spot & ETF paus sangat kokoh, hindari counter-trend shorting.",
                keyTargetPrice = roundToPrecision(curr + delta * 3.5, pair.pipPrecision),
                isConfirmed = true
            )

            TimeFrame.H4 -> TimeframeAnalysis(
                timeframe = TimeFrame.H4,
                pairSymbol = pair.symbol,
                bias = MarketBias.BULLISH,
                structure = StructureStatus.BULLISH_BOS,
                keyZoneText = "Target Zona Likuidasi: Supply H4 & CME Gap di ${roundToPrecision(curr + delta * 2.0, pair.pipPrecision)} & Demand Rebound di ${roundToPrecision(curr - delta * 0.8, pair.pipPrecision)}",
                structureNote = "Harga sedang meretest Key Demand H4 (3 bulan) untuk mengumpulkan likuiditas sebelum ekspansi ke resistance atas.",
                summary = "ZONA & TARGET: Area Demand H4 fresh dan belum termitigasi. Menargetkan ekspansi harga ke pool likuidasi H4.",
                keyTargetPrice = roundToPrecision(curr + delta * 2.0, pair.pipPrecision),
                isConfirmed = true
            )

            TimeFrame.H1 -> TimeframeAnalysis(
                timeframe = TimeFrame.H1,
                pairSymbol = pair.symbol,
                bias = MarketBias.BULLISH,
                structure = StructureStatus.BULLISH_CHOCH,
                keyZoneText = "Struktur H1 (4 Minggu): Bullish CHoCH terkonfirmasi pada harga ${roundToPrecision(curr + delta * 0.3, pair.pipPrecision)}",
                structureNote = "Struktur internal 4 minggu telah menyelesaikan fase re-akumulasi Wyckoff dan membentuk Bullish CHoCH.",
                summary = "STRUKTUR PASAR: Terkonfirmasi Bullish CHoCH diikuti Higher Low (HL). Struktur mikro selaras dengan bias makro D1 & target H4.",
                keyTargetPrice = roundToPrecision(curr + delta * 1.5, pair.pipPrecision),
                isConfirmed = true
            )

            TimeFrame.M15 -> TimeframeAnalysis(
                timeframe = TimeFrame.M15,
                pairSymbol = pair.symbol,
                bias = MarketBias.BULLISH,
                structure = StructureStatus.BULLISH_BOS,
                keyZoneText = "M15 Entry Order Block: ${roundToPrecision(curr - delta * 0.1, pair.pipPrecision)} | SL: ${roundToPrecision(curr - delta * 0.35, pair.pipPrecision)}",
                structureNote = "Terjadi liquidity sweep pada level swing low sebelumnya dan terbentuk Bullish Engulfing pada area Demand M15.",
                summary = "TRIGGER ENTRY TERPENUHI: Sinyal Entry Buy/Long limit terkonfirmasi dengan Risk-to-Reward 1:4.2 untuk Spot & Futures!",
                keyTargetPrice = roundToPrecision(curr + delta * 2.0, pair.pipPrecision),
                isConfirmed = true
            )
        }
    }

    /**
     * Synthesizes all 4 timeframes into a Unified Multi-TF Confluence Crypto Trade Setup.
     */
    fun computeMultiTfConfluence(
        pair: TradingPair,
        d1: TimeframeAnalysis,
        h4: TimeframeAnalysis,
        h1: TimeframeAnalysis,
        m15: TimeframeAnalysis
    ): MultiTfConfluence {
        val curr = pair.currentPrice
        val delta = when (pair.symbol) {
            "BTCUSDT" -> 1100.0
            "ETHUSDT" -> 65.0
            "SOLUSDT" -> 4.2
            "BNBUSDT" -> 12.0
            "XRPUSDT" -> 0.015
            "DOGEUSDT" -> 0.0045
            else -> pair.currentPrice * 0.018
        }

        val d1Bullish = d1.bias == MarketBias.BULLISH
        val d1Bearish = d1.bias == MarketBias.BEARISH
        val h4Aligned = (d1Bullish && h4.bias == MarketBias.BULLISH) || (d1Bearish && h4.bias == MarketBias.BEARISH)
        val h1Aligned = (d1Bullish && (h1.structure == StructureStatus.BULLISH_BOS || h1.structure == StructureStatus.BULLISH_CHOCH)) ||
                (d1Bearish && (h1.structure == StructureStatus.BEARISH_BOS || h1.structure == StructureStatus.BEARISH_CHOCH))
        val m15Aligned = m15.isConfirmed

        var score = 0
        if (d1.isConfirmed) score += 25
        if (h4Aligned) score += 25
        if (h1Aligned) score += 25
        if (m15Aligned) score += 25

        val direction = when {
            score >= 75 && d1Bullish -> "STRONG LONG / BUY 🟢"
            score >= 75 && d1Bearish -> "STRONG SHORT / SELL 🔴"
            score >= 50 && d1Bullish -> "MODERATE LONG (Wait M15 Confirmation) 🟡"
            score >= 50 && d1Bearish -> "MODERATE SHORT (Wait M15 Confirmation) 🟡"
            else -> "NEUTRAL / WAIT FOR CONFLUENCE ⚪"
        }

        val entryPrice: Double
        val stopLoss: Double
        val tp1: Double
        val tp2: Double

        if (d1Bullish) {
            entryPrice = roundToPrecision(curr - (delta * 0.1), pair.pipPrecision)
            stopLoss = roundToPrecision(curr - (delta * 0.35), pair.pipPrecision)
            tp1 = roundToPrecision(curr + (delta * 0.8), pair.pipPrecision)
            tp2 = roundToPrecision(curr + (delta * 2.0), pair.pipPrecision)
        } else {
            entryPrice = roundToPrecision(curr + (delta * 0.1), pair.pipPrecision)
            stopLoss = roundToPrecision(curr + (delta * 0.35), pair.pipPrecision)
            tp1 = roundToPrecision(curr - (delta * 0.8), pair.pipPrecision)
            tp2 = roundToPrecision(curr - (delta * 2.0), pair.pipPrecision)
        }

        val risk = abs(entryPrice - stopLoss)
        val reward = abs(tp2 - entryPrice)
        val rr = if (risk > 0) String.format(Locale.US, "1 : %.1f", reward / risk) else "1 : 3.0"

        val action = when {
            score >= 75 -> "Semua 4 Time Frame Telah Selaras! Setup Crypto memiliki probabilitas sangat tinggi (High Confluence). Pasang order Buy/Long sesuai trigger M15."
            score >= 50 -> "Bias Siklus D1 dan Target H4 telah cocok, namun tunggu sweep likuidasi dan konfirmasi di H1/M15 sebelum entry."
            else -> "Time frame belum sinkron. Menunggu konfirmasi struktur sebelum membuka posisi di pasar kripto."
        }

        return MultiTfConfluence(
            pairSymbol = pair.symbol,
            direction = direction,
            confluenceScore = score,
            d1BiasAnalysis = "${d1.bias.label} (${d1.summary})",
            h4TargetZoneAnalysis = h4.keyZoneText,
            h1StructureAnalysis = "${h1.structure.label} (${h1.structureNote})",
            m15EntryTriggerAnalysis = m15.keyZoneText,
            entryPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit1 = tp1,
            takeProfit2 = tp2,
            riskRewardRatio = rr,
            isD1Aligned = d1.isConfirmed,
            isH4Aligned = h4Aligned,
            isH1Aligned = h1Aligned,
            isM15Aligned = m15Aligned,
            recommendedAction = action
        )
    }

    private fun roundToPrecision(value: Double, precision: Int): Double {
        val factor = 10.0.pow(precision.toDouble())
        return (value * factor).roundToLong() / factor
    }
}
