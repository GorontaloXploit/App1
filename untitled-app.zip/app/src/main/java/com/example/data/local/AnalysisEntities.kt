package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timeframe_analyses")
data class AnalysisEntity(
    @PrimaryKey val id: String, // e.g. "XAUUSD_D1", "XAUUSD_H4", etc.
    val pairSymbol: String,
    val timeframeCode: String, // "D1", "H4", "H1", "M15"
    val bias: String, // "BULLISH", "BEARISH", "NEUTRAL"
    val structure: String,
    val keyZoneText: String,
    val structureNote: String,
    val summary: String,
    val keyTargetPrice: Double,
    val isConfirmed: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "saved_setups")
data class SavedSetupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pairSymbol: String,
    val signalType: String, // "BUY", "SELL", "WAIT"
    val confluenceScore: Int,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val riskReward: String,
    val d1Bias: String,
    val h4Target: String,
    val h1Structure: String,
    val m15Trigger: String,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
