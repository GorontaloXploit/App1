package com.example.data.model

enum class MarketBias(val label: String, val badgeColorHex: Long) {
    BULLISH("BULLISH 🟢", 0xFF00E676),
    BEARISH("BEARISH 🔴", 0xFFFF3D57),
    NEUTRAL("SIDEWAYS / RANGE 🟡", 0xFFFFD600)
}

enum class StructureStatus(val label: String, val description: String) {
    BULLISH_BOS("Bullish BOS", "Break of Structure ke atas, konfirmasi kelanjutan tren naik"),
    BEARISH_BOS("Bearish BOS", "Break of Structure ke bawah, konfirmasi kelanjutan tren turun"),
    BULLISH_CHOCH("Bullish CHoCH", "Change of Character dari bearish berbalik menguat ke bullish"),
    BEARISH_CHOCH("Bearish CHoCH", "Change of Character dari bullish berbalik melemah ke bearish"),
    CONSOLIDATION("Konsolidasi / Range", "Harga tertahan di antara support dan resistance")
}

enum class ZoneType(val label: String, val isDemandOrSupport: Boolean) {
    DEMAND("Demand Zone (Buy Area)", true),
    SUPPLY("Supply Zone (Sell Area)", false),
    SUPPORT("Key Support", true),
    RESISTANCE("Key Resistance", false)
}

enum class TimeFrame(
    val code: String,
    val title: String,
    val periodSpan: String,
    val role: String,
    val roleExplanation: String,
    val historicalCandles: Int
) {
    D1(
        code = "D1",
        title = "Daily (D1)",
        periodSpan = "Siklus 9 Bulan",
        role = "Bias Siklus Makro Crypto",
        roleExplanation = "Menganalisa arah tren makro 9 bulan (Halving Cycle, tren akumulasi paus / institusi, dan swing high/low dominan).",
        historicalCandles = 210
    ),
    H4(
        code = "H4",
        title = "4 Hours (H4)",
        periodSpan = "3 Bulan",
        role = "Zona Likuidasi & Target",
        roleExplanation = "Menganalisa area target likuidasi besar, CME Gap, serta Major Supply & Demand kripto 3 bulan.",
        historicalCandles = 270
    ),
    H1(
        code = "H1",
        title = "1 Hour (H1)",
        periodSpan = "4 Minggu",
        role = "Struktur Pasar & Wyckoff",
        roleExplanation = "Memvalidasi perubahan struktur (BOS / CHoCH) dan pola Akumulasi/Distribusi internal 4 minggu.",
        historicalCandles = 320
    ),
    M15(
        code = "M15",
        title = "15 Menit (M15)",
        periodSpan = "Eksekusi Intraday",
        role = "Trigger Entry & Liq Sweep",
        roleExplanation = "Mencari titik masuk presisi setelah terjadi sweep likuidasi leverage tinggi (OB refinement, FVG) untuk spot & futures.",
        historicalCandles = 240
    )
}

data class TradingPair(
    val symbol: String,
    val name: String,
    val category: String, // "Layer 1", "Smart Contract", "Meme", etc.
    val currentPrice: Double,
    val change24h: Double,
    val pipPrecision: Int,
    val pipUnit: Double,
    val fundingRate: Double = 0.010, // in %
    val openInterest: String = "$12.5B",
    val volume24hUsd: String = "$24.8B",
    val networkType: String = "L1 Blockchain"
) {
    companion object {
        val DEFAULT_PAIRS = listOf(
            TradingPair(
                symbol = "BTCUSDT",
                name = "Bitcoin",
                category = "Layer 1 / Store of Value",
                currentPrice = 64850.00,
                change24h = 2.45,
                pipPrecision = 2,
                pipUnit = 1.0,
                fundingRate = 0.0112,
                openInterest = "$14.8B",
                volume24hUsd = "$32.4B",
                networkType = "Bitcoin Mainnet"
            ),
            TradingPair(
                symbol = "ETHUSDT",
                name = "Ethereum",
                category = "Smart Contracts / DeFi",
                currentPrice = 3485.50,
                change24h = 3.12,
                pipPrecision = 2,
                pipUnit = 0.1,
                fundingRate = 0.0085,
                openInterest = "$7.2B",
                volume24hUsd = "$15.6B",
                networkType = "Ethereum EVM"
            ),
            TradingPair(
                symbol = "SOLUSDT",
                name = "Solana",
                category = "High-Speed L1 / Ecosystem",
                currentPrice = 152.40,
                change24h = 5.80,
                pipPrecision = 2,
                pipUnit = 0.01,
                fundingRate = 0.0145,
                openInterest = "$2.1B",
                volume24hUsd = "$4.9B",
                networkType = "Solana Sealevel"
            ),
            TradingPair(
                symbol = "BNBUSDT",
                name = "BNB Chain",
                category = "Exchange / Ecosystem L1",
                currentPrice = 586.20,
                change24h = 1.25,
                pipPrecision = 2,
                pipUnit = 0.1,
                fundingRate = 0.0090,
                openInterest = "$850M",
                volume24hUsd = "$1.8B",
                networkType = "BNB Smart Chain"
            ),
            TradingPair(
                symbol = "XRPUSDT",
                name = "Ripple",
                category = "Cross-Border / Payments",
                currentPrice = 0.5840,
                change24h = 4.10,
                pipPrecision = 4,
                pipUnit = 0.0001,
                fundingRate = 0.0075,
                openInterest = "$620M",
                volume24hUsd = "$1.4B",
                networkType = "XRP Ledger"
            ),
            TradingPair(
                symbol = "DOGEUSDT",
                name = "Dogecoin",
                category = "Meme / Top Market Cap",
                currentPrice = 0.1245,
                change24h = 6.30,
                pipPrecision = 4,
                pipUnit = 0.0001,
                fundingRate = 0.0160,
                openInterest = "$430M",
                volume24hUsd = "$980M",
                networkType = "Dogecoin Core"
            )
        )
    }
}

data class Candle(
    val id: Int,
    val timestamp: Long,
    val timeLabel: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
}

data class TradingZone(
    val id: String,
    val priceTop: Double,
    val priceBottom: Double,
    val type: ZoneType,
    val label: String,
    val timeframe: TimeFrame,
    val isMitigated: Boolean = false,
    val description: String = ""
)

enum class LiquidityType(val title: String, val badge: String, val isShortLiquidation: Boolean) {
    SHORT_LIQUIDATION("Short Liquidation Pool (BSL)", "Shorts Squeeze Magnet", true),
    LONG_LIQUIDATION("Long Liquidation Pool (SSL)", "Longs Cascade Magnet", false),
    EQUAL_HIGHS("Equal Highs (EQH) Liquidity", "Clustered Resistance Sweep", true),
    EQUAL_LOWS("Equal Lows (EQL) Liquidity", "Clustered Support Sweep", false),
    LEVERAGE_HOTSPOT("Hotspot Likuidasi 50x-100x", "Ekstrem Leverage Cluster", true)
}

data class LiquidityLevel(
    val id: String,
    val price: Double,
    val type: LiquidityType,
    val intensity: Float, // 0.1f (mild) to 1.0f (extreme liquidity)
    val estimatedVolumeMillions: Double,
    val leverageTier: String = "50x & 100x",
    val description: String
)

data class TimeframeAnalysis(
    val timeframe: TimeFrame,
    val pairSymbol: String,
    val bias: MarketBias,
    val structure: StructureStatus,
    val keyZoneText: String,
    val structureNote: String,
    val summary: String,
    val keyTargetPrice: Double,
    val isConfirmed: Boolean,
    val updatedAt: Long = System.currentTimeMillis()
)

data class MultiTfConfluence(
    val pairSymbol: String,
    val direction: String, // "STRONG BUY", "STRONG SELL", "WAITING FOR CONFIRMATION"
    val confluenceScore: Int, // 0 to 100%
    val d1BiasAnalysis: String,
    val h4TargetZoneAnalysis: String,
    val h1StructureAnalysis: String,
    val m15EntryTriggerAnalysis: String,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val riskRewardRatio: String,
    val isD1Aligned: Boolean,
    val isH4Aligned: Boolean,
    val isH1Aligned: Boolean,
    val isM15Aligned: Boolean,
    val recommendedAction: String
)
