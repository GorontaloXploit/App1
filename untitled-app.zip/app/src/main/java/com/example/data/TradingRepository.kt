package com.example.data

import com.example.data.local.AnalysisDao
import com.example.data.local.AnalysisEntity
import com.example.data.local.SavedSetupEntity
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

class TradingRepository(private val analysisDao: AnalysisDao) {

    fun getAnalysesForPair(pair: TradingPair): Flow<Map<TimeFrame, TimeframeAnalysis>> {
        return analysisDao.getAnalysesForPair(pair.symbol).map { entities ->
            val map = mutableMapOf<TimeFrame, TimeframeAnalysis>()

            // Load saved entities
            entities.forEach { entity ->
                val tf = try {
                    TimeFrame.valueOf(entity.timeframeCode)
                } catch (e: Exception) {
                    null
                }
                if (tf != null) {
                    val bias = try {
                        MarketBias.valueOf(entity.bias)
                    } catch (e: Exception) {
                        MarketBias.BULLISH
                    }
                    val structure = try {
                        StructureStatus.valueOf(entity.structure)
                    } catch (e: Exception) {
                        StructureStatus.BULLISH_BOS
                    }

                    map[tf] = TimeframeAnalysis(
                        timeframe = tf,
                        pairSymbol = entity.pairSymbol,
                        bias = bias,
                        structure = structure,
                        keyZoneText = entity.keyZoneText,
                        structureNote = entity.structureNote,
                        summary = entity.summary,
                        keyTargetPrice = entity.keyTargetPrice,
                        isConfirmed = entity.isConfirmed,
                        updatedAt = entity.updatedAt
                    )
                }
            }

            // Fill any missing timeframe with default analysis
            TimeFrame.values().forEach { tf ->
                if (!map.containsKey(tf)) {
                    map[tf] = MarketDataProvider.getDefaultTimeframeAnalysis(pair, tf)
                }
            }

            map.toMap()
        }.catch { e ->
            // Fallback gracefully without crashing
            val fallbackMap = TimeFrame.values().associateWith { tf ->
                MarketDataProvider.getDefaultTimeframeAnalysis(pair, tf)
            }
            emit(fallbackMap)
        }
    }

    suspend fun saveAnalysis(analysis: TimeframeAnalysis) {
        try {
            val entity = AnalysisEntity(
                id = "${analysis.pairSymbol}_${analysis.timeframe.code}",
                pairSymbol = analysis.pairSymbol,
                timeframeCode = analysis.timeframe.code,
                bias = analysis.bias.name,
                structure = analysis.structure.name,
                keyZoneText = analysis.keyZoneText,
                structureNote = analysis.structureNote,
                summary = analysis.summary,
                keyTargetPrice = analysis.keyTargetPrice,
                isConfirmed = analysis.isConfirmed,
                updatedAt = System.currentTimeMillis()
            )
            analysisDao.insertOrUpdateAnalysis(entity)
        } catch (e: Exception) {
            // Silently handle error
        }
    }

    suspend fun initializeDefaultAnalysesIfEmpty(pair: TradingPair) {
        try {
            val entities = TimeFrame.values().map { tf ->
                val defaultAnalysis = MarketDataProvider.getDefaultTimeframeAnalysis(pair, tf)
                AnalysisEntity(
                    id = "${pair.symbol}_${tf.code}",
                    pairSymbol = pair.symbol,
                    timeframeCode = tf.code,
                    bias = defaultAnalysis.bias.name,
                    structure = defaultAnalysis.structure.name,
                    keyZoneText = defaultAnalysis.keyZoneText,
                    structureNote = defaultAnalysis.structureNote,
                    summary = defaultAnalysis.summary,
                    keyTargetPrice = defaultAnalysis.keyTargetPrice,
                    isConfirmed = defaultAnalysis.isConfirmed,
                    updatedAt = System.currentTimeMillis()
                )
            }
            analysisDao.insertAllAnalyses(entities)
        } catch (e: Exception) {
            // Silently handle error
        }
    }

    val savedSetups: Flow<List<SavedSetupEntity>> = analysisDao.getAllSavedSetups()
        .catch { emit(emptyList()) }

    suspend fun saveSetup(setup: SavedSetupEntity) {
        try {
            analysisDao.insertSavedSetup(setup)
        } catch (e: Exception) {
            // Silently handle error
        }
    }

    suspend fun deleteSetup(id: Long) {
        try {
            analysisDao.deleteSavedSetup(id)
        } catch (e: Exception) {
            // Silently handle error
        }
    }
}
