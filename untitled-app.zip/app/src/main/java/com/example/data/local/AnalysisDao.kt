package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisDao {

    @Query("SELECT * FROM timeframe_analyses WHERE pairSymbol = :pairSymbol")
    fun getAnalysesForPair(pairSymbol: String): Flow<List<AnalysisEntity>>

    @Query("SELECT * FROM timeframe_analyses WHERE id = :id LIMIT 1")
    suspend fun getAnalysisById(id: String): AnalysisEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAnalysis(analysis: AnalysisEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAnalyses(analyses: List<AnalysisEntity>)

    @Query("SELECT * FROM saved_setups ORDER BY timestamp DESC")
    fun getAllSavedSetups(): Flow<List<SavedSetupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedSetup(setup: SavedSetupEntity): Long

    @Query("DELETE FROM saved_setups WHERE id = :id")
    suspend fun deleteSavedSetup(id: Long)
}
